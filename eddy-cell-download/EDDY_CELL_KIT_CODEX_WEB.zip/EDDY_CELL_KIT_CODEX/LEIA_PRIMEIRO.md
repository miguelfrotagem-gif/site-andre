# EDDY CELL — KIT VISUAL PARA CODEX

Este ZIP reúne as imagens APROVADAS do projeto, duas fotos reais enviadas pelo cliente, a logo original e o prompt de implementação.

## Ordem do site
1. HERO — `01_REFERENCIAS_SITE/01_HERO.png`
2. SERVIÇOS — `01_REFERENCIAS_SITE/02_SERVICOS.png`
3. PRODUTOS — `01_REFERENCIAS_SITE/03_PRODUTOS.png`
4. SOBRE — `01_REFERENCIAS_SITE/04_SOBRE.png`
5. CONTATO — `01_REFERENCIAS_SITE/05_CONTATO.png`

## Fotos e logo
- `02_FOTOS_REAIS/foto_01_troca_bateria_motorola.png` — foto real de reparo, mostra aparelho aberto e baterias.
- `02_FOTOS_REAIS/foto_02_celular_aberto_bancada.png` — foto real de celular aberto em bancada técnica. Não confundir com prova visual de troca de tela.
- `03_IDENTIDADE_E_REFERENCIAS_ORIGINAIS/logo_original_usuario.png` — logo original enviada pelo cliente: a fonte da verdade para a marca.
- `03_IDENTIDADE_E_REFERENCIAS_ORIGINAIS/logo_faixa_recorte.png` — recorte útil, mantendo a original intacta.
- `03_IDENTIDADE_E_REFERENCIAS_ORIGINAIS/inspiracao_01_nexus_escura.png` e `inspiracao_02_hero_clara.png` — referências de composição, não identidade de marca.

## Cuidados importantes
- As cinco imagens de `01_REFERENCIAS_SITE` são mockups para ORIENTAR O DESIGN, não para serem inseridas inteiras como background ou como site pronto.
- As fotos de loja nos mockups são ILUSTRATIVAS, não fotos comprovadamente reais da Eddy Cell. Não afirmar o contrário.
- Telefones, endereços, horários, garantias, selos e outros dados que apareçam nos mockups podem ser FICTÍCIOS. NÃO reutilizar como informações reais. Deixar os campos de configuração claramente pendentes se não houver dados fornecidos.
- O usuário pediu expressamente para remover o carrinho de compras e o ícone de pessoa/conta do menu. Ignorar esses elementos mesmo que ainda apareçam em alguma imagem antiga.
- Não usar 'prints do site' como elementos clicáveis. Implementar layout real, responsivo e sem textos baked-in.
- Seguir o texto de `PROMPT_PARA_CODEX.md` para implementação.
