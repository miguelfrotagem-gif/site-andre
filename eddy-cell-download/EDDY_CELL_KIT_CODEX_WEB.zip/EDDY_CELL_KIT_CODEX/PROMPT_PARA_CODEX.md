# PROMPT COMPLETO PARA CODEX — SITE EDDY CELL

Você é um desenvolvedor frontend sênior e diretor de arte digital. Implemente um site de verdade para **EDDY CELL — Assistência Técnica & Acessórios**, usando o KIT de imagens anexo como referências visuais e fotos reais. Faça o trabalho diretamente no repositório atual e respeite a stack existente. Se o repositório estiver vazio, crie um frontend moderno e leve. Inspecione antes de alterar.

## Resultado esperado
Site premium brasileiro, com design visualmente muito próximo dos 5 mockups, SEM cara genérica de IA: preto, grafite, branco, vermelho EDDY CELL, gradientes discretos e nitidez realista. Não exagerar em luz neon, brilho, sombras ou elementos decorativos. Design sofisticado, tipografia moderna, espaçamento refinado, hierarquia clara. Sem margens laterais vazias acidentais, sem elementos cortados. NÃO use a imagem de referência da seção como imagem única da seção. Crie os componentes com HTML/React/CSS real e responsivo; incorpore as fotos originais nos cards que as pedem.

## Referências visuais obrigatórias, nesta ordem
1. `01_REFERENCIAS_SITE/01_HERO.png`: hero — marca forte, texto impactante alinhado à esquerda, dispositivo visual à direita. Use o design como orientação, não a imagem inteira.
2. `01_REFERENCIAS_SITE/02_SERVICOS.png`: seção Serviços — cards organizados, usar as 2 fotos reais fornecidas onde couberem. Renderizar títulos, parágrafos e CTAs em elementos reais.
3. `01_REFERENCIAS_SITE/03_PRODUTOS.png`: Produtos — categorias capinhas, películas, carregadores, cabos, fones e acessórios, cards clean e bem fotografados. Não inventar estoque ou preços.
4. `01_REFERENCIAS_SITE/04_SOBRE.png`: Sobre — visual bipartido com conteúdo institucional e ambientação da loja como ILUSTRAÇÃO conceitual; se não houver foto real do local, não fazer parecer fotografia documental da Eddy Cell.
5. `01_REFERENCIAS_SITE/05_CONTATO.png`: Contato — área escura premium com textos à esquerda e formulário real à direita; inspirado no estilo fornecido, mas sem inventar telefone, endereço ou horário.

## Identidade visual
- Usar `03_IDENTIDADE_E_REFERENCIAS_ORIGINAIS/logo_original_usuario.png` como identidade visual original. O arquivo `logo_faixa_recorte.png` é uma alternativa de recorte útil, mas verifique enquadramento e nitidez; não recriar logotipo com lettering diferente.
- Cores base: preto/grafite e vermelho vivo (#E21B23 aproximado), branco suave, cinza neutro. Responsividade e contraste são prioridade.
- Fontes premium e legíveis: por exemplo, Manrope ou Plus Jakarta Sans para títulos, Inter para textos, sempre com fallbacks seguros.
- Header fixo ou sticky refinado: logo à esquerda, links INÍCIO, SERVIÇOS, PRODUTOS, SOBRE, CONTATO. Exibir destaque do item ativo ao rolar (IntersectionObserver), sem bug de seção ativa. Menu mobile com abertura/fechamento real, foco acessível e navegação por âncora.
- IMPORTANTE: SEM ÍCONE DE CARRINHO; SEM ÍCONE DE PESSOA/PERFIL; sem botões decorativos que não funcionem.

## HERO
- Headline sugerida: “Seu dispositivo, em boas mãos.” com ênfase controlada em vermelho.
- Texto conciso: “Assistência técnica e acessórios para manter seu aparelho funcionando como deveria.”
- CTA primário “Solicitar orçamento” e secundário “Conhecer serviços” com estados hover/focus reais.
- A arte de smartphone pode usar asset permitido ou composição profissional; não incorporar uma imagem do mockup com texto/menus duplicados. Não afirmar marcas de produtos não confirmadas.
- A hero deve ocupar aproximadamente a primeira viewport no desktop, com menu visível e os elementos bem enquadrados. Mobile: empilhar, priorizar texto + CTA, imagem proporcional sem cortar o conteúdo crítico.

## SERVIÇOS — FOTOS REAIS OBRIGATÓRIAS
- Card 1: **Troca de bateria** usando `02_FOTOS_REAIS/foto_01_troca_bateria_motorola.png`.
  Texto sugerido: “Substituição de baterias desgastadas para recuperar a autonomia e o desempenho do aparelho.”
- Card 2: **Manutenção interna** usando `02_FOTOS_REAIS/foto_02_celular_aberto_bancada.png`.
  Texto sugerido: “Avaliação e manutenção de componentes internos, com cuidado em cada etapa do serviço.”
- Outros serviços como troca de tela, reparo de conector, limpeza técnica e atualização de software podem ter cards VISUAIS consistentes, sem usar fotos erradas para aparentar um serviço específico.
- Botões “Solicitar orçamento” devem levar a CONTATO ou iniciar WhatsApp com mensagem predefinida apenas se o número real for configurado.
- NÃO prometer “peças originais”, “garantia X meses” ou “reparo em X minutos” sem comprovação e parâmetros reais.

## PRODUTOS
- Categorias de acessórios: Capinhas, Películas, Carregadores, Cabos, Fones / acessórios.
- Visual no mesmo grid premium; imagens podem ser ilustrativas de cada categoria, devidamente contextualizadas. NÃO inventar preços, avaliações, estoque ou marcas exclusivas.
- CTAs reais para navegar às categorias ou solicitar informações, não links vazios.

## SOBRE
- “Conheça a Eddy Cell” + texto institucional sóbrio e verdadeiro, sem inventar ano de fundação, total de clientes, equipe certificada, número de lojas ou certificações.
- Texto sugerido: “A Eddy Cell é focada em assistência técnica e acessórios para celulares, com atenção aos detalhes, comunicação clara e cuidado com cada dispositivo.”
- Reforços discretos: atendimento atencioso, avaliação cuidadosa, soluções para o dia a dia. NÃO transformar mockup de fachada/conceito em fotografia real da loja.

## CONTATO
- Cabeçalho com “Entre em contato com a Eddy Cell”.
- Formulário com nome, WhatsApp, modelo do aparelho, serviço desejado, descrição opcional, consentimento de privacidade quando necessário.
- Validar campos, mensagens de erro/sucesso reais. Configurar envio de fato (por exemplo, WhatsApp com mensagem estruturada com base nas informações preenchidas) quando o telefone real estiver disponível. Sem telefone, o botão não deve fingir sucesso: deve informar que o destino está pendente de configuração.
- Dados reais de telefone, endereço e horários NÃO foram informados. Inserir placeholders claros no código/config, ocultos ou indicados como “A confirmar”, sem exibir números ou endereços fictícios.
- Não criar mapa de endereço inventado.

## INTERAÇÕES, ACESSIBILIDADE E PERFORMANCE
- Menus, botões e formulário funcionais e navegáveis; nenhuma interação cenográfica.
- Microanimações elegantes: reveal leve ao entrar na viewport, hover de 150-250ms, respeitar `prefers-reduced-motion`. Nenhum movimento exagerado.
- Scroll suave, offsets corretos no sticky header, foco visível, labels, ARIA, imagens com alt, sem layout shift desnecessário.
- Testar desktop (1440 / 1920) e mobile (390 / 430) e tablet; não pode haver scroll horizontal, cortes ou textos sobrepostos.
- Utilizar `object-fit: cover` com enquadramento intencional nas fotos reais; nunca esticar imagens. Otimizar assets e lazy load fora da primeira dobra.
- Evitar menus duplicados em seções e repetição da logo gigante em excesso.
- SEO: título, meta description, headings semânticos, OpenGraph e favicon adequados, sem dados falsos.

## Critérios de entrega
- Entregar os arquivos editados com instruções de execução e deploy.
- Executar build/lint se disponíveis, corrigir erros e verificar funcionamento das rotas/âncoras.
- Garantir que o site se aproxime das imagens aprovadas, mas SEM reproduzir falhas de texto/ortografia ou dados falsos dos mockups.
- Prioridade máxima: fidelidade visual, funcionalidade real, limpeza estética e MOBILE ainda melhor que desktop.
